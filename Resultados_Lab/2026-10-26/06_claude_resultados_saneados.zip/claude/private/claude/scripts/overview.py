import json, math, statistics as st
from datetime import datetime
A=["aave","ada","aixbt","algo","apt","btc"]
D={a:json.load(open(f"private/claude/data/{a}.json")) for a in A}
def closes(a,i): return [c["close"] for c in D[a]["candles"][str(i)]]
def sma(x,n): return sum(x[-n:])/n
def ret(x,n): return x[-1]/x[-1-n]-1
def logr(x): return [math.log(x[i]/x[i-1]) for i in range(1,len(x))]
btc=closes("btc",1440); rb=logr(btc)
for a in A:
    d=D[a]; c=closes(a,1440); cd=D[a]["candles"]["1440"]; q=d["quote"]
    mid=(q["bid"]+q["ask"])/2; spread=(q["ask"]-q["bid"])/mid*1e4
    vol30=[x["close"]*x["volume"] for x in cd[-30:]]
    hi=max(range(len(c)),key=lambda i:c[i]); lo=min(range(len(c)),key=lambda i:c[i])
    r=logr(c); n=min(len(r),len(rb)); rr=r[-n:]; bb=rb[-n:]
    cov=st.covariance(rr[-180:],bb[-180:]); beta=cov/st.variance(bb[-180:]); corr=st.correlation(rr[-180:],bb[-180:])
    cg=d["fundamentals"]["coingecko"][0]
    print(f"\n{a.upper()} close={c[-1]} spread={spread:.1f}bps askdepth~{q['ask_depth_near_quote']:.0f} USD? kraken_med_daily_usd_vol30={st.median(vol30):,.0f}")
    print(f"  ret 7d {ret(c,7):+.1%} 30d {ret(c,30):+.1%} 90d {ret(c,90):+.1%} 180d {ret(c,180):+.1%} 365d {ret(c,365):+.1%}")
    print(f"  vs SMA50 {c[-1]/sma(c,50)-1:+.1%} SMA100 {c[-1]/sma(c,100)-1:+.1%} SMA200 {c[-1]/sma(c,200)-1:+.1%}; 2y hi {c[hi]} {cd[hi]['timestamp'][:10]} lo {c[lo]} {cd[lo]['timestamp'][:10]} dd_from_hi {c[-1]/c[hi]-1:+.1%}")
    print(f"  vol ann 90d {st.stdev(r[-90:])*math.sqrt(365):.0%}  beta180 {beta:.2f} corr180 {corr:.2f}  mcap {cg['market_cap']:,} fdv {cg.get('fully_diluted_valuation')} cg_vol24 {cg['total_volume']:,}")
    # monthly closes last 12
    print("  month-ends:", [ (x["timestamp"][:7], x["close"]) for i,x in enumerate(cd) if i+1<len(cd) and cd[i+1]["timestamp"][8:10]=="01"][-14:])
    if "defillama_chain_tvl" in d["fundamentals"]:
        t=d["fundamentals"]["defillama_chain_tvl"]; 
        print("  defillama:", type(t).__name__, (t[-1] if isinstance(t,list) else str(t)[:200]), (t[-31] if isinstance(t,list) and len(t)>31 else ""), (t[-366] if isinstance(t,list) and len(t)>366 else ""))
for s in ["fred_DFF","fred_DGS10","fred_DTWEXBGS","fred_VIXCLS"]:
    o=D["btc"]["fundamentals"][s]["observations"]; print(s,[(x["date"],x["value"]) for x in o[:1]+o[-1:]])
