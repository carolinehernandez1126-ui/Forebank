import importlib.util,json
from pathlib import Path
import pandas as pd
from research_lab.models import Dataset
from research_lab.io import read_json,write_json
from research_lab.analytics import frame
from research_lab.backtest import moving_block_bootstrap
P=Path('data/next-twenty-20261026');O=Path('outputs/next-twenty-20261026');M=read_json(O/'manifest.json');spec=importlib.util.spec_from_file_location('frozen','private/strategy_study.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);mod.self_tests();out={};series={}
for row in M['assets']:
 n=row['asset'];d=Dataset.model_validate(read_json(P/(n+'.json')));x=mod.prepared(frame(d.candles[1440]));series[n]=x.close.pct_change();split=len(x)-120
 result={'bars':len(x),'warmup':200,'holdout_start_index':split,'independent_oos':False,'latest_signals':{'T':bool(x.signal_T.iloc[-1]),'R':bool(x.signal_R.iloc[-1])},'strategies':{}}
 for kind in['T','R']:
  q={'full_eligible':mod.simulate_strategy(x,kind,200,len(x))}
  if split>200:
   q.update({label:mod.simulate_strategy(x,kind,start,end)for label,start,end in[('development',200,split),('holdout',split,len(x))]});stress=mod.simulate_strategy(x,kind,split,len(x),80,30);q['holdout_double_costs']={k:v for k,v in stress.items()if k not in['daily_return_series','trade_details']};q['holdout_bootstrap']=moving_block_bootstrap(q['holdout']['daily_return_series'],samples=2000,block=10,seed=42)
  else:q['partition_gap']='Only '+str(len(x)-200)+' eligible daily bars after warmup; cannot form both development and120-bar holdout without changing protocol.'
  result['strategies'][kind]=q
 result['benchmark_20pct_buy_hold']={'full_eligible':mod.buy_hold(x,200,len(x))}
 if split>200:result['benchmark_20pct_buy_hold'].update({label:mod.buy_hold(x,start,end)for label,start,end in[('development',200,split),('holdout',split,len(x))]})
 out[n]=result;print(n,json.dumps({'bars':len(x),'dev_bars':max(0,split-200),'signals':result['latest_signals'],'full':{k:{z:v['full_eligible'][z]for z in['trades','return','max_drawdown','profit_factor']}for k,v in result['strategies'].items()},'oos':{k:{z:v['holdout'][z]for z in['trades','return','max_drawdown']}if'holdout'in v else None for k,v in result['strategies'].items()}}),flush=True)
write_json(O/'strategy-study.json',out);a=pd.concat(series,axis=1).dropna();write_json(O/'daily-correlation.json',{'observations':len(a),'pearson':a.corr().to_dict(),'spearman':a.corr(method='spearman').to_dict()});print('Completed20 assets,40 reference simulations; HYPE partition unavailable,not fabricated.')
