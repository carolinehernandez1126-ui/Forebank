from pathlib import Path
from decimal import Decimal,ROUND_DOWN
from research_lab.io import read_json,write_json,digest
from research_lab.models import Dataset
from research_lab.analytics import frame
p=Path('data/second-five-20261026');o=Path('outputs/second-five-20261026');s=read_json(o/'supplementary.json');out={}
for n in ['AVAX','ASTER','BCH']:
 d=Dataset.model_validate(read_json(p/(n+'.json')));r=read_json(o/(n+'-dossier.json'));h=r['timeframes']['60']['latest'];four=r['timeframes']['240']['latest'];day=r['timeframes']['1440']['latest'];tick=Decimal(str(d.instrument.tick_size))
 rnd=lambda x:float((Decimal(str(x))/tick).to_integral_value(rounding=ROUND_DOWN)*tick)
 low10=min(c.low for c in d.candles[1440][-10:]);zone_low=four['donchian_low_20']
 if n=='AVAX':E=rnd(zone_low+.5*h['atr_14']);S=rnd(zone_low-four['atr_14']);T=rnd(day['ema_50']);horizon=5
 elif n=='ASTER':E=rnd(zone_low+.25*h['atr_14']);S=rnd(low10-.5*four['atr_14']);T=rnd(day['bollinger_upper']);horizon=3
 else:E=rnd(zone_low+.5*h['atr_14']);S=rnd(low10-.25*four['atr_14']);T=rnd(day['bollinger_upper']);horizon=7
 C=.0055;unit=E-S+(E+S)*C;reward=T-E-(T+E)*C;rr=reward/unit
 # Public illustrative capital10000,risk5; no real account assumption.
 cap=min(d.quote.ask_depth_near_quote*.01,s['assets'][n]['recheck']['depth_cap_usd']);q=min(5/unit,cap/E,2000/E);q=float(Decimal(str(q)).quantize(Decimal(1).scaleb(-d.instrument.quantity_decimals),rounding=ROUND_DOWN))
 stress_c=.011;stress_rr=(T-E-(T+E)*stress_c)/(E-S+(E+S)*stress_c)
 assert S<zone_low<=E<T and rr>=2 and q>=d.instrument.min_quantity and q*E>=d.instrument.min_cost
 out[n]={'symbol':d.instrument.symbol,'zone_low':zone_low,'entry_ceiling':E,'stop':S,'target':T,'horizon_days':horizon,'net_rr_target':rr,'double_cost_rr':stress_rr,'unit_risk':unit,'unit_reward':reward,'qty_illustrative_equity10000':q,'notional_illustrative':q*E,'risk_illustrative':q*unit,'conservative_depth_cap_usd':cap,'dataset_sha256':digest(d),'rules_designed_after_data':True,'backtested':False}
 print(n,out[n])
write_json(o/'conditional-plans.json',out)
