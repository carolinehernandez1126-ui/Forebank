from pathlib import Path
from decimal import Decimal,ROUND_DOWN
from research_lab.io import read_json,write_json
from research_lab.models import Dataset
from research_lab.analytics import frame
P=Path('data/next-twenty-20261026');O=Path('outputs/next-twenty-20261026');M=read_json(O/'manifest.json');S=read_json(O/'supplementary.json')if(O/'supplementary.json').exists()else read_json(O/'supplement-progress.json');out={}
for row in M['assets']:
 n=row['asset'];d=Dataset.model_validate(read_json(P/(n+'.json')));r=read_json(O/(n+'-dossier.json'));h=r['timeframes']['60']['latest'];v=r['timeframes']['240']['latest'];a=r['timeframes']['1440']['latest'];tick=Decimal(str(d.instrument.tick_size));rnd=lambda x:float((Decimal(str(x))/tick).to_integral_value(rounding=ROUND_DOWN)*tick)
 # Type is determined by regime before any reward/risk is calculated.
 typ='R'if a['adx_14']<=25 else'M';lo=v['donchian_low_20'];E=rnd(lo+.5*h['atr_14']);stop=rnd(min(c.low for c in d.candles[1440][-10:])-.25*v['atr_14'])if typ=='R'else rnd(lo-v['atr_14']);T=rnd(a['bollinger_upper'])if typ=='R'else rnd(a['ema_50']);unit=E-stop+(E+stop)*.0055;reward=T-E-(T+E)*.0055
 rr=reward/unit if unit>0 else None;re=S['assets'][n]['recheck'];cap=min(d.quote.ask_depth_near_quote*.01,re['depth_cap_usd']);q=0.
 if unit>0:q=float(Decimal(str(min(5/unit,cap/E,2000/E))).quantize(Decimal(1).scaleb(-d.instrument.quantity_decimals),rounding=ROUND_DOWN))
 spread1=(d.quote.ask-d.quote.bid)/((d.quote.ask+d.quote.bid)/2)*10000;reasons=[]
 if not(stop<lo<=E<T):reasons.append('invalid_geometry')
 if rr is None or rr<2:reasons.append('net_rr_below2')
 if max(spread1,re['spread_bps'])>20:reasons.append('spread_over20_in_snapshot')
 if q<d.instrument.min_quantity or q*E<d.instrument.min_cost:reasons.append('quantity_or_notional_minimum')
 stressunit=E-stop+(E+stop)*.011;stressrr=(T-E-(T+E)*.011)/stressunit if stressunit>0 else None
 result={'type':typ,'type_rule':'R if daily ADX14<=25 else M','zone_low':lo,'entry_ceiling':E,'stop':stop,'target':T,'rr_net_target':rr,'double_cost_rr':stressrr,'qty_illustrative_equity10000':q,'risk_illustrative':q*unit,'notional_illustrative':q*E,'conservative_depth_cap_usd':cap,'screen_passed':not reasons,'reasons':reasons,'dataset_sha256':row['dataset_sha256'],'signal_at_cutoff':bool(lo<=h['close']<=E and h['close']>h['open']and h['close']>(h['high']+h['low'])/2 and h['low']>stop)};out[n]=result
 print(n,typ,'E',E,'S',stop,'T',T,'RR',round(rr,3)if rr is not None else None,'stress',round(stressrr,3)if stressrr is not None else None,'cap',round(cap,2),'risk10k',round(q*unit,3),'pass',not reasons,reasons)
write_json(O/'plan-screen.json',out)
