from pathlib import Path
from decimal import Decimal, ROUND_DOWN
import numpy as np
import pandas as pd
from research_lab.io import read_json, write_json
from research_lab.models import Dataset
from research_lab.analytics import frame, indicators

P=Path('data/next-twenty-20261026'); O=Path('outputs/next-twenty-20261026')

def features(d):
    h=indicators(frame(d.candles[60])).reset_index(); h['available']=h.timestamp+pd.Timedelta(hours=1)
    f=indicators(frame(d.candles[240]))[['atr_14','donchian_low_20']].rename(columns={'atr_14':'a4','donchian_low_20':'low4'}).reset_index()
    f['four_available']=f.timestamp+pd.Timedelta(hours=4); f=f.drop(columns='timestamp')
    daily=indicators(frame(d.candles[1440])); daily['low10']=daily.low.rolling(10).min()
    daily=daily[['ema_50','bollinger_upper','low10','adx_14']].rename(columns={'ema_50':'ema50d','bollinger_upper':'bbupd','adx_14':'adxd'}).reset_index()
    daily['daily_available']=daily.timestamp+pd.Timedelta(days=1); daily=daily.drop(columns='timestamp')
    a=pd.merge_asof(h.sort_values('available'),f.sort_values('four_available'),left_on='available',right_on='four_available',direction='backward')
    a=pd.merge_asof(a.sort_values('available'),daily.sort_values('daily_available'),left_on='available',right_on='daily_available',direction='backward')
    assert (a.four_available<=a.available).all() and (a.daily_available<=a.available).all()
    # Causal regime choice, not a choice of the more profitable historical variant.
    a['kind']=np.where(a.adxd<=25,'R','M'); a['ceiling']=a.low4+.5*a.atr_14
    a['stop']=np.where(a.kind=='R',a.low10-.25*a.a4,a.low4-a.a4)
    a['target']=np.where(a.kind=='R',a.bbupd,a.ema50d)
    tick=Decimal(str(d.instrument.tick_size))
    for k in ['ceiling','stop','target']:
        a[k]=a[k].map(lambda x:float((Decimal(str(x))/tick).to_integral_value(rounding=ROUND_DOWN)*tick) if np.isfinite(x) else x)
    a['signal']=(a.close>=a.low4)&(a.close<=a.ceiling)&(a.close>a.open)&(a.close>(a.high+a.low)/2)&(a.low>a.stop)
    return a.set_index('timestamp')

def simulate(a,C=.0055):
    cash=10000.; pos=None; trades=[]; curve=[cash]; lastday=None; seen=0
    skipped={'geometry_or_gap':0,'rr':0,'same_day':0,'daily_pause':0,'budget':0}; daily_start={}; loss=0.
    def sell(i,raw,why):
        nonlocal pos,cash,loss
        proceeds=pos['q']*raw*(1-C); pnl=proceeds-pos['cost']; cash+=proceeds
        trades.append({**pos,'exit_time':a.index[i].isoformat(),'exit_raw':float(raw),'pnl':pnl,'R':pnl/pos['risk'],'reason':why}); loss+=max(0,-pnl); pos=None
    for i in range(200,len(a)):
        row=a.iloc[i]; prev=a.iloc[i-1]; day=a.index[i].date(); exited=False
        equity=cash+(pos['q']*row.open if pos else 0); daily_start.setdefault(day,equity)
        if pos:
            if row.open<=pos['stop']:sell(i,row.open,'stop_gap'); exited=True
            elif row.open>=pos['target']:sell(i,row.open,'target_gap'); exited=True
            elif i-pos['index']>=pos['horizon']:sell(i,row.open,'time'); exited=True
        if not pos and not exited and prev.signal and i<len(a)-1:
            seen+=1; E=float(row.open); S=float(prev.stop); T=float(prev.target)
            unit=E-S+(E+S)*C; reward=T-E-(T+E)*C
            if day==lastday:skipped['same_day']+=1
            elif cash<daily_start[day]*(1-.0015):skipped['daily_pause']+=1
            elif loss>=50 or len(trades)>=20:skipped['budget']+=1
            elif not(S<prev.low4<=E<=prev.ceiling<T):skipped['geometry_or_gap']+=1
            elif unit<=0 or reward/unit<2:skipped['rr']+=1
            else:
                buy=E*(1+C); q=min(cash*.0005/unit,cash*.2/buy); cost=q*buy
                pos={'entry_time':a.index[i].isoformat(),'index':i,'entry':E,'stop':S,'target':T,'q':q,'cost':cost,'risk':q*unit,'type':prev.kind,'horizon':168 if prev.kind=='R' else 120}
                cash-=cost; lastday=day
        if pos:
            if row.low<=pos['stop']:sell(i,pos['stop'],'stop_both' if row.high>=pos['target'] else 'stop')
            elif row.high>=pos['target']:sell(i,pos['target'],'target')
        if pos and i==len(a)-1:sell(i,row.close,'final')
        curve.append(cash+(pos['q']*row.close if pos else 0))
    curve=np.array(curve); assert abs(sum(t['pnl']for t in trades)-(curve[-1]-10000))<1e-6
    return {'start':a.index[200].isoformat(),'end':a.index[-1].isoformat(),'bars':len(a)-200,'trades':len(trades),'signals_while_flat':seen,'skipped':skipped,'return':float(curve[-1]/10000-1),'max_drawdown':float(np.min(curve/np.maximum.accumulate(curve)-1)),'trade_details':trades}

def boundaries():
    idx=pd.date_range('2025-01-01',periods=210,freq='h',tz='UTC')
    b=pd.DataFrame({'open':100.,'high':101.,'low':99.,'close':100.,'low4':95.,'ceiling':105.,'stop':90.,'target':140.,'signal':False,'kind':'R'},index=idx); b.loc[idx[201],'signal']=True
    both=b.copy();both.loc[idx[202],['high','low']]=[150,80];z=simulate(both)
    assert z['trades']==1 and z['trade_details'][0]['entry_time']==idx[202].isoformat() and z['trade_details'][0]['reason']=='stop_both' and abs(z['trade_details'][0]['R']+1)<1e-9
    gap=b.copy(); gap.loc[idx[203],'open']=80;z=simulate(gap);assert z['trade_details'][0]['reason']=='stop_gap' and z['trade_details'][0]['R']<-1
    no=b.copy();no.loc[idx[202],'open']=106;assert simulate(no)['trades']==0
    assert simulate(b,0)['return']>simulate(b)['return']
    assert all(t['risk']<=5.000001 for t in simulate(b)['trade_details'])

if __name__=='__main__':
    boundaries(); out={}
    for item in read_json(O/'manifest.json')['assets']:
        n=item['asset']; d=Dataset.model_validate(read_json(P/(n+'.json')));a=features(d)
        short=d.model_copy(update={'candles':{k:v[:-24 if k==60 else 6 if k==240 else 1]for k,v in d.candles.items()}});b=features(short)
        safe=b.index[b.available<=min(frame(short.candles[1440]).index[-1]+pd.Timedelta(days=1),frame(short.candles[240]).index[-1]+pd.Timedelta(hours=4))]
        for k in ['ceiling','stop','target','adxd']:assert np.allclose(a.loc[safe,k],b.loc[safe,k],equal_nan=True)
        out[n]={'base':simulate(a),'double_costs':simulate(a,.011),'latest_signal':bool(a.signal.iloc[-1]),'diagnostic_only':True,'independent_oos':False,'causality':'passed'}
        print(n,{k:v for k,v in out[n]['base'].items()if k!='trade_details'},flush=True)
    write_json(O/'pilot-specific-diagnostic.json',out)
    print('20 causal diagnostics and boundary checks passed; no historical books, no independent validation.')
