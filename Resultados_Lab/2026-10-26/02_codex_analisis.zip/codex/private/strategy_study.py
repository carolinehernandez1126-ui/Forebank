from __future__ import annotations
import hashlib,json
from pathlib import Path
import numpy as np
import pandas as pd
from research_lab.models import Dataset
from research_lab.io import read_json,write_json
from research_lab.analytics import frame,indicators
from research_lab.backtest import moving_block_bootstrap

NAMES=['AAVE','ADA','AIXBT','ALGO','APT']

def prepared(df):
    x=indicators(df)
    x['prior_h20']=x.high.shift(1).rolling(20).max()
    x['lo10']=x.low.rolling(10).min()
    x['signal_T']=(x.ema_50>x.ema_200)&(x.close>x.ema_200)&(x.close>x.prior_h20)
    x['signal_R']=(x.rsi_14<30)&(x.close<x.bollinger_lower)
    return x


def simulate_strategy(x,kind,start,end,fee_bps=40,slippage_bps=15,risk_fraction=.0025):
    fee,slip=fee_bps/10000,slippage_bps/10000
    cash=50000.;units=0.;position=None;trades=[];curve=[];exposure=[]
    skipped={'gap':0,'net_rr':0,'invalid':0}; signal_count=0
    multiple,holding=(3,20) if kind=='T' else (2.5,10)
    def close(i,raw,reason):
        nonlocal cash,units,position
        proceeds=units*raw*(1-slip)*(1-fee)
        pnl=proceeds-position['cost']
        trades.append({**position,'exit_time':x.index[i].isoformat(),'exit_index':i,
                       'exit_raw':float(raw),'reason':reason,'pnl':pnl,'R':pnl/position['risk'],
                       'holding_bars':i-position['entry_index']+1})
        cash+=proceeds;units=0.;position=None
    for i in range(start,end):
        row=x.iloc[i];prev=x.iloc[i-1];exited=False;held=bool(units)
        if units:
            if row.open<=position['stop']:
                close(i,row.open,'stop_gap');exited=True
            elif row.open>=position['target']:
                close(i,row.open,'target_gap');exited=True
            elif (kind=='T' and prev.close<prev.ema_50) or (kind=='R' and prev.close>=prev.sma_20):
                close(i,row.open,'mean_or_trend_exit');exited=True
            elif i-position['entry_index']>=holding:
                close(i,row.open,'time_exit');exited=True
        if not units and not exited and bool(prev['signal_'+kind]) and i<end-1:
            signal_count+=1
            atr=float(prev.atr_14);entry=float(row.open)
            if not np.isfinite(atr) or atr<=0:
                skipped['invalid']+=1
            elif abs(entry-float(prev.close))>atr:
                skipped['gap']+=1
            else:
                stop=min(float(prev.lo10),entry-2*atr) if kind=='T' else entry-2*atr
                target=entry+multiple*(entry-stop)
                buy=entry*(1+slip)*(1+fee)
                loss=buy-stop*(1-slip)*(1-fee)
                reward=target*(1-slip)*(1-fee)-buy
                if stop<=0 or loss<=0:
                    skipped['invalid']+=1
                elif reward/loss<2:
                    skipped['net_rr']+=1
                else:
                    qty=min(cash*risk_fraction/loss,cash*.2/buy)
                    cost=qty*buy
                    position={'entry_time':x.index[i].isoformat(),'entry_index':i,'entry_raw':entry,
                              'entry_fill':entry*(1+slip),'stop':stop,'target':target,'quantity':qty,
                              'cost':cost,'risk':qty*loss,'net_rr':reward/loss}
                    cash-=cost;units=qty;held=True
        if units:
            # The same bar can touch both barriers. Use the adverse ordering.
            if row.low<=position['stop']:
                close(i,position['stop'],'stop_both' if row.high>=position['target'] else 'stop');exited=True
            elif row.high>=position['target']:
                close(i,position['target'],'target');exited=True
        if units and i==end-1:
            close(i,row.close,'final_liquidation');exited=True
        value=cash+units*float(row.close)
        curve.append(value)
        exposure.append(bool(held or units))
    a=np.r_[50000.,np.array(curve)]
    returns=a[1:]/a[:-1]-1
    wins=[t['pnl'] for t in trades if t['pnl']>0];losses=[t['pnl'] for t in trades if t['pnl']<0]
    pf=sum(wins)/-sum(losses) if losses else None
    net_pnl=sum(t['pnl'] for t in trades)
    if abs(net_pnl-(a[-1]-50000))>1e-6: raise AssertionError('PnL accounting mismatch')
    return {'start':x.index[start].isoformat(),'end':x.index[end-1].isoformat(),'bars':end-start,
            'return':float(a[-1]/50000-1),'max_drawdown':float(np.min(a/np.maximum.accumulate(a)-1)),
            'trades':len(trades),'wins':len(wins),'win_rate':len(wins)/len(trades) if trades else None,
            'profit_factor':pf,'mean_R':float(np.mean([t['R'] for t in trades])) if trades else None,
            'exposure_bar_fraction':float(np.mean(exposure)),'signals_while_flat':signal_count,
            'skipped':skipped,'forced_final_exits':sum(t['reason']=='final_liquidation' for t in trades),
            'daily_return_series':returns.tolist(),'trade_details':trades}


def buy_hold(x,start,end,fee_bps=40,slippage_bps=15):
    fee,slip=fee_bps/10000,slippage_bps/10000
    qty=10000/(float(x.open.iloc[start])*(1+slip)*(1+fee))
    c=40000+qty*x.close.iloc[start:end].to_numpy(dtype=float)
    c[-1]=40000+qty*float(x.close.iloc[end-1])*(1-slip)*(1-fee)
    wealth=np.r_[50000,c]
    return {'return':float(c[-1]/50000-1),'max_drawdown':float(np.min(wealth/np.maximum.accumulate(wealth)-1))}


def self_tests():
    idx=pd.date_range('2025-01-01',periods=10,tz='UTC')
    base=pd.DataFrame({'open':100.,'high':101.,'low':99.,'close':100.,'volume':10.,'ema_50':90.,'ema_200':80.,'sma_20':110.,'atr_14':5.,'lo10':95.,'signal_T':False,'signal_R':False},index=idx)
    base.iloc[1,base.columns.get_loc('signal_T')]=True
    a=simulate_strategy(base,'T',2,8)
    assert a['trades']==1 and a['trade_details'][0]['entry_time']==idx[2].isoformat()
    # Future bars cannot create an earlier entry.
    altered=base.copy();altered.loc[idx[8]:,'signal_T']=True
    assert simulate_strategy(altered,'T',2,8)==a
    both=base.copy();both.loc[idx[2],['high','low']]=[140,80]
    b=simulate_strategy(both,'T',2,8)
    assert b['trade_details'][0]['reason']=='stop_both'
    assert abs(b['trade_details'][0]['R']+1)<1e-10
    gap=base.copy();gap.loc[idx[3],'open']=80
    g=simulate_strategy(gap,'T',2,8)
    assert g['trade_details'][0]['reason']=='stop_gap' and g['trade_details'][0]['R'] < -1
    free=simulate_strategy(base,'T',2,8,0,0)
    assert a['return']<free['return']
    assert all(t['cost']<=10000.00001 for t in a['trade_details'])
    print('Custom strategy checks: causal entry, no future leakage, adverse barrier ordering, gaps, costs, exposure and PnL passed.')


if __name__=='__main__':
    self_tests();allout={};daily={}
    for name in NAMES:
        data=Dataset.model_validate(read_json('data/'+name+'.json'))
        x=prepared(frame(data.candles[1440]));daily[name]=x.close.pct_change()
        if any(x.index.to_series().diff().dropna()!=pd.Timedelta(days=1)): raise AssertionError('Daily gaps')
        split=len(x)-120
        result={'bars':len(x),'warmup':200,'holdout_start_index':split,'initial_capital':50000,
                'risk_fraction_per_entry':.0025,'max_asset_exposure':.20,'base_fee_bps':40,'base_slip_bps':15,
                'latest_signals':{'T':bool(x.signal_T.iloc[-1]),'R':bool(x.signal_R.iloc[-1])},'strategies':{}}
        for kind in ['T','R']:
            out={}
            for label,start,end in [('development',200,split),('holdout',split,len(x)),('full_eligible',200,len(x))]:
                out[label]=simulate_strategy(x,kind,start,end)
            stress=simulate_strategy(x,kind,split,len(x),80,30)
            out['holdout_double_costs']={k:v for k,v in stress.items() if k not in ['daily_return_series','trade_details']}
            out['holdout_bootstrap']=moving_block_bootstrap(out['holdout']['daily_return_series'],samples=2000,block=10,seed=42)
            result['strategies'][kind]=out
        result['benchmark_20pct_buy_hold']={'development':buy_hold(x,200,split),'holdout':buy_hold(x,split,len(x)),'full_eligible':buy_hold(x,200,len(x))}
        allout[name]=result
        write_json('outputs/'+name+'/strategy-tests.json',result)
    aligned=pd.concat(daily,axis=1).dropna()
    write_json('outputs/daily-correlation.json',{'observations':len(aligned),'pearson':aligned.corr().to_dict(),'spearman':aligned.corr(method='spearman').to_dict()})
    write_json('outputs/strategy-study.json',allout)
    print(json.dumps({n:{'signals':v['latest_signals'],'strategies':{k:{s:{m:r[s][m] for m in ['return','max_drawdown','trades','win_rate','profit_factor','mean_R']} for s in ['development','holdout','full_eligible']} for k,r in v['strategies'].items()},'benchmark':v['benchmark_20pct_buy_hold']} for n,v in allout.items()}))
