# Protocolo previo a observar los resultados

Sesión 2026-10-25, Codex. Universo fijo en orden: AAVE, ADA, AIXBT, ALGO, APT.
Base de código: a2c4f006983a4ae15bbc35d07e38f8e55e6c160f. Datos propios y cache aislada.
No leer opiniones/resultados de Claude. Solo se publican estudio final y conclusiones bajo Codex.

TENDENCIA: EMA50>EMA200; cierre>EMA200; cierre supera el máximo de las 20 velas anteriores. Entrada a apertura siguiente. Stop inicial min(mínimo10 previo, entrada-2ATR14 previo). Objetivo 3R. Salida si cierre previo<EMA50 o 20 velas de permanencia, a apertura siguiente. No seguir gaps de entrada mayores a 1 ATR desde cierre previo.
REVERSION: RSI14<30 y cierre<Bollinger inferior20. Entrada a apertura siguiente. Stop entrada-2ATR14 previo; objetivo 2.5R. Salida si cierre previo>=SMA20 o 10 velas de permanencia, a apertura siguiente. Mismo filtro de gap.
Ambas long/flat spot; solo velas cerradas diarias. Señales causales; no parámetros optimizados. Si stop y objetivo coinciden intrabar, asumir stop primero; gaps de salida ejecutados en apertura adversa. Liquidación al cierre final, con costos y exposición final declarados.
Comisión 40 bps y deslizamiento15 bps por lado; sensibilidad doblando ambos, no sustituir fee real. Riesgo por operación 0.25%, exposición por activo20%; comparar cash y buy/hold con costos. Últimas120 velas intactas como holdout; desarrollo antes de ese corte; mínimo200 velas de warm-up.
Reportar operaciones, retorno, drawdown, PF, win rate, R promedio, bootstrap por bloques y exposición. No atribuir significancia con pocas operaciones. Dos estrategias x cinco activos =10 ensayos explícitos; no retocar parámetros después del resultado. Baseline EMA del Lab solo benchmark adicional, no validación de estas reglas.
No afirmar cumplimiento MDL en tiempo continuo desde velas diarias. Construir dimensionamiento prospectivo independiente y sumar riesgo concurrente sin crédito de diversificación. Capital de referencia50K y USD provisional; cuenta no reconciliada. No inventar revisión Claude ni estado de cuenta.
