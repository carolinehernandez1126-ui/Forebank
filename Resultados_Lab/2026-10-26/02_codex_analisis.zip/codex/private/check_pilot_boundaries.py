import importlib.util
import pandas as pd
s=importlib.util.spec_from_file_location('pilot_diagnostic','private/diagnostic_second_five.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
idx=pd.date_range('2025-01-01',periods=210,freq='h',tz='UTC')
b=pd.DataFrame({'open':100.,'high':101.,'low':99.,'close':100.,'low4':95.,'ceiling':105.,'stop':90.,'target':140.,'signal':False},index=idx);b.loc[idx[201],'signal']=True
both=b.copy();both.loc[idx[202],['high','low']]=[150,80];a=m.simulate(both,'BCH');assert a['trades']==1 and a['trade_details'][0]['entry_time']==idx[202].isoformat()and a['trade_details'][0]['exit_reason']=='stop_both';assert abs(a['trade_details'][0]['R']+1)<1e-9
g=b.copy();g.loc[idx[203],'open']=80;z=m.simulate(g,'BCH');assert z['trade_details'][0]['exit_reason']=='stop_gap'and z['trade_details'][0]['R']<-1
no=b.copy();no.loc[idx[202],'open']=106;assert m.simulate(no,'BCH')['trades']==0
free=m.simulate(b,'BCH',(0,0));paid=m.simulate(b,'BCH');assert free['return']>paid['return'];assert all(t['risk']<=5.000001 for t in paid['trade_details'])
print('Pilot simulator boundary tests passed: next-bar entry, double-touch ordering, adverse gaps, price ceiling, costs and risk cap.')
