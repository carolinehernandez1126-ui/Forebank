from pathlib import Path
import importlib.util,sys,json
from decimal import Decimal,ROUND_DOWN
import numpy as np,pandas as pd
from research_lab.io import read_json,write_json
from research_lab.models import Dataset
from research_lab.analytics import frame
from research_lab.backtest import moving_block_bootstrap

label=sys.argv[1];P=Path('data',label);O=Path('outputs',label);M=read_json(O/'manifest.json')
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
ref=module('frozen_ref','private/strategy_study.py');diag=module('frozen_q','private/diagnostic_twenty.py');ref.self_tests();diag.boundaries()
S=read_json(O/'supplementary.json');B={};Q={};X={};daily={}
for item in M['assets']:
 n=item['asset'];d=Dataset.model_validate(read_json(P/(n+'.json')));r=read_json(O/(n+'-dossier.json'));x=ref.prepared(frame(d.candles[1440]));daily[n]=x.close.pct_change();split=len(x)-120
 b={'bars':len(x),'warmup':200,'independent_oos':False,'latest_signals':{'T':bool(x.signal_T.iloc[-1]),'R':bool(x.signal_R.iloc[-1])},'strategies':{},'benchmark_20pct_buy_hold':{}}
 for kind in ['T','R']:
  v={}
  if len(x)>200:v['full_eligible']=ref.simulate_strategy(x,kind,200,len(x))
  if split>200:
   v.update({part:ref.simulate_strategy(x,kind,i,j)for part,i,j in [('development',200,split),('holdout',split,len(x))]})
   stress=ref.simulate_strategy(x,kind,split,len(x),80,30);v['holdout_double_costs']={k:z for k,z in stress.items()if k not in ['daily_return_series','trade_details']};v['holdout_bootstrap']=moving_block_bootstrap(v['holdout']['daily_return_series'],samples=2000,block=10,seed=42)
  else:v['partition_gap']=f'{len(x)} daily bars: insufficient for warmup200, development and holdout120 under frozen protocol.'
  b['strategies'][kind]=v
 if len(x)>200:b['benchmark_20pct_buy_hold']['full_eligible']=ref.buy_hold(x,200,len(x))
 if split>200:b['benchmark_20pct_buy_hold'].update({part:ref.buy_hold(x,i,j)for part,i,j in [('development',200,split),('holdout',split,len(x))]})
 B[n]=b
 h=r['timeframes']['60']['latest'];v=r['timeframes']['240']['latest'];a=r['timeframes']['1440']['latest'];tick=Decimal(str(d.instrument.tick_size));rnd=lambda z:float((Decimal(str(z))/tick).to_integral_value(rounding=ROUND_DOWN)*tick)
 typ='R'if a['adx_14']<=25 else'M';lo=v['donchian_low_20'];Eraw=rnd(lo+.5*h['atr_14']);stop=rnd(min(c.low for c in d.candles[1440][-10:])-.25*v['atr_14'])if typ=='R'else rnd(lo-v['atr_14']);T=rnd(a['bollinger_upper'])if typ=='R'else rnd(a['ema_50'])
 # The original rule requires RR>=2 at the ACTUAL entry inside its zone.
 # Intersect that zone with its algebraic RR bound; never change S/T or expand it.
 # This is a post-observation reporting clarification, not a new fitted strategy;
 # the unchanged historical simulator already tests RR at each actual next open.
 rrbound=rnd(.9945*(T+2*stop)/(3*1.0055));E=min(Eraw,rrbound)if stop<lo<=rrbound and lo<Eraw<T else Eraw
 unit=E-stop+(E+stop)*.0055;reward=T-E-(T+E)*.0055
 re=S['assets'][n]['recheck'];cap=min(d.quote.ask_depth_near_quote*.01,re['depth_cap_usd']);rr=reward/unit if unit>0 else None;q=0.
 if unit>0:q=float(Decimal(str(min(5/unit,cap/E,2000/E))).quantize(Decimal(1).scaleb(-d.instrument.quantity_decimals),rounding=ROUND_DOWN))
 spread=(d.quote.ask-d.quote.bid)/((d.quote.ask+d.quote.bid)/2)*10000;reasons=[]
 if not(stop<lo<=E<T):reasons.append('invalid_geometry')
 if rr is None or rr<2:reasons.append('net_rr_below2')
 if max(spread,re['spread_bps'])>20:reasons.append('spread_over20_in_snapshot')
 if q<d.instrument.min_quantity or q*E<d.instrument.min_cost:reasons.append('quantity_or_notional_minimum')
 if not all(qv['passed']for qv in item['quality'].values()):reasons.append('dataset_quality_gate')
 stressunit=E-stop+(E+stop)*.011;stressrr=(T-E-(T+E)*.011)/stressunit if stressunit>0 else None
 Q[n]={'type':typ,'type_rule':'R if daily ADX14<=25 else M; frozen before this batch','zone_low':lo,'raw_entry_ceiling':Eraw,'rr2_price_bound':rrbound,'entry_ceiling':E,'entry_ceiling_narrowed':E<Eraw,'stop':stop,'target':T,'rr_net_target':rr,'double_cost_rr':stressrr,'qty_illustrative_equity10000':q,'risk_illustrative':q*unit,'notional_illustrative':q*E,'conservative_depth_cap_usd':cap,'screen_passed':not reasons,'reasons':reasons,'dataset_sha256':item['dataset_sha256'],'signal_at_cutoff':bool(lo<=h['close']<=E and h['close']>h['open']and h['close']>(h['high']+h['low'])/2 and h['low']>stop)}
 ah=diag.features(d);short=d.model_copy(update={'candles':{k:z[:-24 if k==60 else 6 if k==240 else 1]for k,z in d.candles.items()}});bh=diag.features(short)
 safe=bh.index[bh.available<=min(frame(short.candles[1440]).index[-1]+pd.Timedelta(days=1),frame(short.candles[240]).index[-1]+pd.Timedelta(hours=4))]
 for k in ['ceiling','stop','target','adxd']:assert np.allclose(ah.loc[safe,k],bh.loc[safe,k],equal_nan=True)
 X[n]={'base':diag.simulate(ah),'double_costs':diag.simulate(ah,.011),'latest_signal':bool(ah.signal.iloc[-1]),'diagnostic_only':True,'independent_oos':False,'causality':'passed'}
 print(n,'RR',round(rr,3)if rr is not None else None,'pass',not reasons,reasons,'Qtrades',X[n]['base']['trades'],'Qreturn',round(X[n]['base']['return']*100,5),'daily',len(x),flush=True)
write_json(O/'strategy-study.json',B);write_json(O/'plan-screen.json',Q);write_json(O/'pilot-specific-diagnostic.json',X)
z=pd.concat(daily,axis=1).dropna();eligible=[n for n in daily if B[n]['bars']>=250];e=pd.concat({n:daily[n]for n in eligible},axis=1).dropna()
write_json(O/'daily-correlation.json',{'all_observations':len(z),'eligible_observations':len(e),'pearson_all':z.corr().to_dict(),'pearson_eligible':e.corr().to_dict(),'spearman_eligible':e.corr(method='spearman').to_dict()})
print('Complete',label,len(Q),'markets;',sum(v['screen_passed']for v in Q.values()),'pass screens')
