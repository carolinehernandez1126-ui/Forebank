from pathlib import Path
import hashlib,json
from decimal import Decimal,ROUND_DOWN
from research_lab.providers import PublicClient,collect
from research_lab.store import Store
from research_lab.io import write_json,digest,utcnow
from research_lab.analytics import dossier,frame,indicators
folder=Path('data/pilot-v2-20261026');folder.mkdir(parents=True,exist_ok=True)
out=Path('outputs/pilot-v2-20261026');out.mkdir(parents=True,exist_ok=True)
s=Store(str(folder/'market-cache.sqlite'));c=PublicClient(s);result={'started_at':utcnow().isoformat(),'protocol_sha256':hashlib.sha256(Path('private/PROTOCOLO_V2_20261026.txt').read_bytes()).hexdigest(),'assets':{}}
try:
 for n,pair in [('AAVE','AAVEUSD'),('ADA','ADAUSD'),('AIXBT','AIXBTUSD'),('ALGO','ALGOUSD'),('APT','APTUSD')]:
  d=collect(c,{'symbol':n+'/USD','kraken_pair':pair},[60,240,1440],False,[])
  write_json(folder/(n+'.json'),d);r=dossier(d);write_json(out/(n+'-dossier.json'),r)
  x=indicators(frame(d.candles[60]));z=indicators(frame(d.candles[240]));last=x.iloc[-1]
  entry=Decimal(str(d.quote.ask));tick=Decimal(str(d.instrument.tick_size));sl=Decimal(str(float(x.low.tail(6).min()-.25*last.atr_14)));stop=(sl/tick).to_integral_value(rounding=ROUND_DOWN)*tick
  target=(Decimal(str(float(z.ema_20.iloc[-1])))/tick).to_integral_value(rounding=ROUND_DOWN)*tick
  cost=Decimal('.0055');unit=entry-stop+(entry+stop)*cost;reward=target-entry-(target+entry)*cost
  emax=(target*(1-cost)+2*stop*(1-cost))/(3*(1+cost));emax=(emax/tick).to_integral_value(rounding=ROUND_DOWN)*tick
  near=d.quote.ask_depth_near_quote
  # The signal closes strictly above the six prior bars, not the bar containing itself.
  h6=float(x.high.iloc[-7:-1].max());signal=bool(last.close>h6 and last.close>last.ema_20)
  spread=(d.quote.ask-d.quote.bid)/((d.quote.ask+d.quote.bid)/2)*10000
  res={'dataset_sha256':digest(d),'quote_time':d.quote.as_of.isoformat(),'bid':d.quote.bid,'ask':d.quote.ask,'spread_bps':spread,'depth_ask_10bps_usd':near,'depth_cap_usd':near*.01,'quality':{k:v['quality']for k,v in r['timeframes'].items()},'latest_1h':r['timeframes'][60]['latest']if 60 in r['timeframes']else r['timeframes']['60']['latest'],'latest_4h':r['timeframes'][240]['latest']if 240 in r['timeframes']else r['timeframes']['240']['latest'],'latest_1d':r['timeframes'][1440]['latest']if 1440 in r['timeframes']else r['timeframes']['1440']['latest'],'p1_signal':signal,'previous_six_high':h6,'stop_p1':float(stop),'target_p1':float(target),'rr_at_ask':float(reward/unit)if unit>0 else None,'max_entry_for_rr2':float(emax),'min_quantity':d.instrument.min_quantity,'tick':d.instrument.tick_size,'one_hour_closed_at':(x.index[-1].timestamp()+3600)}
  result['assets'][n]=res
  print(json.dumps({'asset':n,'ask':d.quote.ask,'spread':spread,'depthcap':near*.01,'p1_signal':signal,'stop':float(stop),'target':float(target),'rr':res['rr_at_ask'],'max_entry':float(emax)}),flush=True)
 result['finished_at']=utcnow().isoformat();write_json(out/'assessment.json',result)
finally:c.close();s.close()
