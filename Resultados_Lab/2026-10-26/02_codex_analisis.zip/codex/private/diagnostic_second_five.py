from pathlib import Path
from datetime import timedelta
from decimal import Decimal,ROUND_DOWN
import pandas as pd,numpy as np
from research_lab.io import read_json,write_json
from research_lab.models import Dataset
from research_lab.analytics import frame,indicators
P=Path('data/second-five-20261026');O=Path('outputs/second-five-20261026')
def floor_tick(x,tick):return float((Decimal(str(x))/Decimal(str(tick))).to_integral_value(rounding=ROUND_DOWN)*Decimal(str(tick)))
def features(d,n):
 h=indicators(frame(d.candles[60]));q=indicators(frame(d.candles[240]));day=indicators(frame(d.candles[1440]));day['low10']=day.low.rolling(10).min()
 h=h.reset_index();h['available']=h.timestamp+pd.Timedelta(hours=1)
 q=q[['atr_14','donchian_low_20']].rename(columns={'atr_14':'a4','donchian_low_20':'low4'}).reset_index();q['four_available']=q.timestamp+pd.Timedelta(hours=4);q=q.drop(columns='timestamp')
 day=day[['ema_50','bollinger_upper','low10']].rename(columns={'ema_50':'ema50d','bollinger_upper':'bbupd'}).reset_index();day['daily_available']=day.timestamp+pd.Timedelta(days=1);day=day.drop(columns='timestamp')
 a=pd.merge_asof(h.sort_values('available'),q.sort_values('four_available'),left_on='available',right_on='four_available',direction='backward');a=pd.merge_asof(a.sort_values('available'),day.sort_values('daily_available'),left_on='available',right_on='daily_available',direction='backward')
 assert(a.four_available<=a.available).all()and(a.daily_available<=a.available).all()
 if n=='AVAX':a['ceiling']=a.low4+.5*a.atr_14;a['stop']=a.low4-a.a4;a['target']=a.ema50d
 elif n=='ASTER':a['ceiling']=a.low4+.25*a.atr_14;a['stop']=a.low10-.5*a.a4;a['target']=a.bbupd
 else:a['ceiling']=a.low4+.5*a.atr_14;a['stop']=a.low10-.25*a.a4;a['target']=a.bbupd
 for k in ['ceiling','stop','target']:a[k]=a[k].map(lambda x:floor_tick(x,d.instrument.tick_size)if np.isfinite(x)else x)
 a['signal']=(a.close>=a.low4)&(a.close<=a.ceiling)&(a.close>a.open)&(a.close>(a.high+a.low)/2)&(a.low>a.stop)
 return a.set_index('timestamp')
def simulate(a,n,Cbase=(.004,.0015)):
 fee,slip=Cbase;horizon={'AVAX':120,'ASTER':72,'BCH':168}[n];cash=10000.;pos=None;trades=[];curves=[cash];signals=0;reasons={'gap_or_price':0,'rr':0,'same_day':0};lastday=None
 def sell(i,raw,reason):
  nonlocal cash,pos
  pnl=pos['q']*raw*(1-fee)*(1-slip)-pos['cost'];cash+=pos['q']*raw*(1-fee)*(1-slip);trades.append({**pos,'exit_time':a.index[i].isoformat(),'exit_raw':raw,'pnl':pnl,'R':pnl/pos['risk'],'exit_reason':reason});pos=None
 for i in range(200,len(a)):
  row=a.iloc[i];prev=a.iloc[i-1];exited=False
  if pos:
   if row.open<=pos['stop']:sell(i,row.open,'stop_gap');exited=True
   elif row.open>=pos['target']:sell(i,row.open,'target_gap');exited=True
   elif i-pos['index']>=horizon:sell(i,row.open,'time');exited=True
  if not pos and not exited and prev.signal and i<len(a)-1:
   signals+=1;entry=float(row.open);S=float(prev.stop);T=float(prev.target)
   buy=entry*(1+slip)*(1+fee);unit=buy-S*(1-slip)*(1-fee);reward=T*(1-slip)*(1-fee)-buy
   if a.index[i].date()==lastday:reasons['same_day']+=1
   elif not(S<prev.low4<=entry<=prev.ceiling<T):reasons['gap_or_price']+=1
   elif unit<=0 or reward/unit<2:reasons['rr']+=1
   else:
    q=min(cash*.0005/unit,cash*.2/buy);cost=q*buy;pos={'entry_time':a.index[i].isoformat(),'index':i,'entry':entry,'stop':S,'target':T,'q':q,'cost':cost,'risk':q*unit};cash-=cost;lastday=a.index[i].date()
  if pos:
   if row.low<=pos['stop']:sell(i,pos['stop'],'stop_both'if row.high>=pos['target']else'stop')
   elif row.high>=pos['target']:sell(i,pos['target'],'target')
  if pos and i==len(a)-1:sell(i,row.close,'final')
  curves.append(cash+(pos['q']*row.close if pos else 0))
 curve=np.array(curves);assert abs(sum(t['pnl']for t in trades)-(curve[-1]-10000))<1e-6
 return {'bars_evaluated':len(a)-200,'start':a.index[200].isoformat(),'end':a.index[-1].isoformat(),'trades':len(trades),'signals_while_flat':signals,'skipped':reasons,'return':float(curve[-1]/10000-1),'max_drawdown':float(np.min(curve/np.maximum.accumulate(curve)-1)),'trade_details':trades,'mean_R':float(np.mean([t['R']for t in trades]))if trades else None,'win_rate':sum(t['pnl']>0 for t in trades)/len(trades)if trades else None}
res={}
for n in ['AVAX','ASTER','BCH']:
 d=Dataset.model_validate(read_json(P/(n+'.json')));a=features(d,n)
 # Recompute on truncated inputs and verify common-prefix features cannot see future bars.
 short=d.model_copy(update={'candles':{k:v[:-24 if k==60 else 6 if k==240 else 1]for k,v in d.candles.items()}});b=features(short,n);idx=b.index[b.index+pd.Timedelta(hours=1)<=min(b.daily_available.iloc[-1]+pd.Timedelta(days=1),b.four_available.iloc[-1]+pd.Timedelta(hours=4))]
 # Full overlap with times where both truncated higher intervals are available.
 safe=b.index[b.available<=min((frame(short.candles[1440]).index[-1]+pd.Timedelta(days=1)),(frame(short.candles[240]).index[-1]+pd.Timedelta(hours=4)))]
 for k in['ceiling','stop','target']:assert np.allclose(a.loc[safe,k],b.loc[safe,k],equal_nan=True)
 res[n]={'base':simulate(a,n),'double_costs':simulate(a,n,(.008,.003)),'latest_signal':bool(a.signal.iloc[-1]),'diagnostic_only':True,'rules_designed_after_viewing_market':True,'higher_timeframe_lookahead_checks':'passed'};print(n,{k:v for k,v in res[n]['base'].items()if k!='trade_details'})
write_json(O/'pilot-specific-diagnostic.json',res)
print('Closed-bar availability, prefix causality and PnL checks passed. Not independent OOS; no parameter optimization.')
