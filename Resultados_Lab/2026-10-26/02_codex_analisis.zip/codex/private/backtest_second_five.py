import importlib.util,json
from pathlib import Path
import pandas as pd
from research_lab.models import Dataset
from research_lab.io import read_json,write_json
from research_lab.analytics import frame
from research_lab.backtest import moving_block_bootstrap
spec=importlib.util.spec_from_file_location('frozen_simulator','private/strategy_study.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
mod.self_tests();allout={};series={};p=Path('data/second-five-20261026');o=Path('outputs/second-five-20261026')
for n in ['ARB','ASTER','ATOM','AVAX','BCH']:
 if not(p/(n+'.json')).exists():print('Pending collection '+n);continue
 d=Dataset.model_validate(read_json(p/(n+'.json')));x=mod.prepared(frame(d.candles[1440]));series[n]=x.close.pct_change();split=len(x)-120
 result={'bars':len(x),'warmup':200,'holdout_start_index':split,'latest_signals':{'T':bool(x.signal_T.iloc[-1]),'R':bool(x.signal_R.iloc[-1])},'strategies':{}}
 for kind in ['T','R']:
  q={label:mod.simulate_strategy(x,kind,start,end)for label,start,end in[('development',200,split),('holdout',split,len(x)),('full_eligible',200,len(x))]}
  stress=mod.simulate_strategy(x,kind,split,len(x),80,30);q['holdout_double_costs']={k:v for k,v in stress.items()if k not in['daily_return_series','trade_details']};q['holdout_bootstrap']=moving_block_bootstrap(q['holdout']['daily_return_series'],samples=2000,block=10,seed=42);result['strategies'][kind]=q
 result['benchmark_20pct_buy_hold']={label:mod.buy_hold(x,start,end)for label,start,end in[('development',200,split),('holdout',split,len(x)),('full_eligible',200,len(x))]};allout[n]=result
 print(n,json.dumps({'bars':len(x),'signals':result['latest_signals'],'results':{k:{label:{m:q[label][m]for m in['return','max_drawdown','trades','profit_factor','mean_R']}for label in['development','holdout']}for k,q in result['strategies'].items()}}))
if len(allout)==5:
 write_json(o/'strategy-study.json',allout);aligned=pd.concat(series,axis=1).dropna();write_json(o/'daily-correlation.json',{'observations':len(aligned),'pearson':aligned.corr().to_dict(),'spearman':aligned.corr(method='spearman').to_dict()})
else:raise SystemExit('All five datasets must exist before final output')
